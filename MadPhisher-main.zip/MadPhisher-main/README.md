# MadPhisher
![Madphisher](https://github.com/user-attachments/assets/626f68cc-4214-43c6-adbe-c74379865b32)

<p align="center">
  <img src="https://img.shields.io/badge/Version-2.1-green?style=for-the-badge">
  <img src="https://img.shields.io/github/license/SajidIbnNayeem/Madphisher?style=for-the-badge">
  <img src="https://img.shields.io/github/stars/SajidIbnNayeem/MadPhisher?style=for-the-badge">
  <img src="https://img.shields.io/github/issues/SajidIbnNayeem/MadPhisher?color=red&style=for-the-badge">
  <img src="https://img.shields.io/github/forks/SajidIbnNayeem/MadPhisher?color=teal&style=for-the-badge">
</p>
<p align="center">
  <img src="https://img.shields.io/badge/Author-SajidIbnNayeem-blue?style=flat-square">
  <img src="https://img.shields.io/badge/Open%20Source-Yes-darkgreen?style=flat-square">
  <img src="https://img.shields.io/badge/Maintained%3F-Yes-lightblue?style=flat-square">
  <img src="https://img.shields.io/badge/Written%20In-Bash-darkcyan?style=flat-square">
  <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fhtr-tech%2Fzphisher&title=Visitors&edge_flat=false"/></a>
</p>

<p align="center"><b> A phishing toolkit with 10+ templates.</b></p>

# Disclaimer
<p>Any action and or activities related to <b>MadPhisher</b> is solely your responsibility. The Misuse of toolkit can result in <b>criminal charges</b> brought against the persons in question. <b>The contributors will not held responsible</b> in the event any criminal charges be brought against any individuals misusing this toolkit to break the law.</p>
<b>This toolkit contains materials that can be potentially damaging or dangerous for socialmedia </b>. Referto the laws in your province/country before accessing, using,or in other way utilizing this in a wrong way.
<b>This Tool is made for educational purposes only</b>. Do not attempt to violate the law with anything contained here. <b>If this is your intention, then Get the hell out of her</b>!
it only demonstrates "how phishing works". <b>You shall not misuse the informtion to gain unauthorized access to someones social media</b>.However you may try out this at your own risk.</i>

# Features 
- Latest and updated login pages.
- Beginners friendly

 # Installation
 - Just, Clone this repository -

 ```
  git clone https://github.com/SajidIbnNayeem/MadPhisher.git
 ```

- Now go to cloned directory and run 'Madphisher.sh' - 


```
cd MadPhisher
bash MadPhisher.sh
```
# Screenshots

![Screenshot From 2025-02-13 14-03-02](https://github.com/user-attachments/assets/146ecc8a-9410-4da0-bfed-5f90d944b33f)
![Screenshot From 2025-02-13 14-05-37](https://github.com/user-attachments/assets/35fb97f5-968f-414d-9e65-20b5f721224f)
![Screenshot From 2025-02-13 14-06-04](https://github.com/user-attachments/assets/3ce0e9f4-3240-462b-9a0a-e58eea294e58)

# Access Local Services anywhere using Cloudflared (link generate for public)
<li> You must first install cloudflared</li>
  You have to install Cloudflared from their official website

<li> Access local services anywhere using cloudflared</li>
  
  <li> Open a new terminal(new window) and type</li>
  
  ```
  cloudflared --url localhost:8080
  ```
![screenshot](https://github.com/user-attachments/assets/96f2e07d-36a6-442e-a18f-cbba7b618b13)


- Here you will find another link which you can use - 
  ![Screenshot ](https://github.com/user-attachments/assets/44a5669d-ee00-4847-96eb-455593a2f007)
The link will be like this:- ```https://checking-expires-internet-another.trycloudflare.com```

# Tested On
- Kali Linux -
- Termux -
- Ubuntu -
- Parrot Sec OS -

# Madphisher Termux

 # Installation
 - Just, Clone this repository -

 ```
  git clone https://github.com/SajidIbnNayeem/MadPhisher.git
 ```

- Now go to cloned directory and run 'Madphisher.sh' - 


```
cd MadPhisher
bash MadPhisher.sh
```

![Madphisher](https://github.com/user-attachments/assets/853d35e0-b289-4d31-a425-aa108c221300)





# Access Local Services anywhere using Cloudflared (link generate for public)
<li> You must first install Cloudflared-termux</li>
  You have to install Cloudflared-termux from 
  https://github.com/SajidIbnNayeem/Cloudflared-termux.git
<li> Access local services anywhere using cloudflared</li>
  
  <li> Open a new terminal(new session) and type</li>
  
  ```
  cloudflared --url localhost:8080
  ```
![madphisher](https://github.com/user-attachments/assets/ed357267-e6b6-437c-b49a-8a8f04c7ed8a)


### Connect with me:
<div id="badges">
  <a href="https://github.com/SajidIbnNayeem">
    <img src="https://img.shields.io/badge/Github-white?style=for-the-badge&logo=Github&logoColor=black" alt="Github Badge"/>
  </a>
  
   <a href="https://www.instagram.com/sajid_ibn_nayeem?igsh=MXdnNmttb292MnFuaQ==">
    <img src="https://img.shields.io/badge/Instagram-purple?style=for-the-badge&logo=instagram&logoColor=white" alt="Instagram Badge"/>
  </a>
   
   <a href="https://twitter.com/Sajid_nayeem_">
    <img src="https://img.shields.io/badge/Twitter-blue?style=for-the-badge&logo=twitter&logoColor=white" alt="Twitter Badge"/>
  </a>
</div>

